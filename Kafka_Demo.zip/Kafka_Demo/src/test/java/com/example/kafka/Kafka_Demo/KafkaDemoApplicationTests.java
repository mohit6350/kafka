package com.example.kafka.Kafka_Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
